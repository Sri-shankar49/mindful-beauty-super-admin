import { ReportsTable } from "../components/Reports/ReportsTable"

export const Reports = () => {
    return (
        <div>
            <ReportsTable />
        </div>
    )
}
