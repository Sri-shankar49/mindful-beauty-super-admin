import { SalesTransactionsTable } from "../components/SalesTransactions/SalesTransactionsTable"

export const SalesTransactions = () => {
  return (
    <div>
      <SalesTransactionsTable />
    </div>
  )
}
