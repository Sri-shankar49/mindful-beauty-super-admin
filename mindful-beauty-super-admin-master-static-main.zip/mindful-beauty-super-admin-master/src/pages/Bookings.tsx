import { Outlet } from 'react-router-dom'

export const Bookings = () => {
  return (
    <div>
      <Outlet />
    </div>
  )
}
