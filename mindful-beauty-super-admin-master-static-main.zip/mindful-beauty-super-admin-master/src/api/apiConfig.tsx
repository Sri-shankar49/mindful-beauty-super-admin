
export const apiConfig = () => {
  return (
    <div>apiConfig</div>
  )
}
