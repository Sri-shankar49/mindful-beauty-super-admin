export const Footer = () => {
  return (
    <div className="text-center py-2">
        <p className="text-xs text-mindfulBlack">Copyright &copy; 2024 Mindful Beauty</p>
    </div>
  )
}
